
document.addEventListener("DOMContentLoaded", () => {
    const produtos = document.querySelectorAll(".produto");

    const aparecerProdutos = () => {
        produtos.forEach((produto, index) => {
            setTimeout(() => {
                produto.classList.add("visivel");
            }, index * 200); // Adiciona um atraso para cada produto
        });
    };

    aparecerProdutos();
});

// Função para fazer login (apenas para exemplo)
function fazerLogin(event) {
    event.preventDefault();
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
    
    if (email === "ruan.rodrigues292004@gmail.com" && senha === "1234") {
        alert("Login bem-sucedido!");
    } else {
        alert("Email ou senha incorretos!");
    }
}

// Função para adicionar item ao carrinho
function adicionarAoCarrinho(produto) {
    let carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
    carrinho.push(produto);
    localStorage.setItem('carrinho', JSON.stringify(carrinho));
    alert(`${produto.nome} foi adicionado ao carrinho!`);
}

// Função para exibir itens do carrinho
function exibirCarrinho() {
    const carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
    const carrinhoDiv = document.getElementById('carrinho');
    carrinhoDiv.innerHTML = '';

    if (carrinho.length === 0) {
        carrinhoDiv.innerHTML = '<p>O carrinho está vazio.</p>';
        return;
    }

    carrinho.forEach((item, index) => {
        const itemDiv = document.createElement('div');
        itemDiv.className = 'item-carrinho';
        itemDiv.innerHTML = `
            <p>${item.nome}</p>
            <p>Preço: R$ ${item.preco}</p>
            <button onclick="removerDoCarrinho(${index})">Remover</button>
        `;
        carrinhoDiv.appendChild(itemDiv);
    });
}

// Função para remover item do carrinho
function removerDoCarrinho(index) {
    let carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
    carrinho.splice(index, 1);
    localStorage.setItem('carrinho', JSON.stringify(carrinho));
    exibirCarrinho();
}

// Função para encerrar compra
function encerrarCompra() {
    localStorage.removeItem('carrinho');
    alert("Compra encerrada com sucesso!");
    exibirCarrinho();
}

// Função para voltar à vitrine
function voltarVitrine() {
    window.location.href = 'vitrine.html';
}

// Exemplo de produtos (normalmente seriam carregados de um servidor)
const produtos = [
    { nome: "Smartphone XYZ", preco: 1999.99 },
    { nome: "Notebook ABC", preco: 2999.99 },
    { nome: "Tablet zx", preco: 1499.99 },
    { nome: "teclado hyperx", preco: 199.00 },
    { nome: "mouse iluminado", preco: 350.00 },
    { nome: "Smart Tv", preco: 3599.00 },
    { nome: "Smartphone opera", preco: 1299.00 },
    { nome: "Smartphone A50", preco: 1999.99 },
    { nome: "iphone XR", preco: 4399.00},

];

// Exibir produtos na vitrine
function exibirVitrine() {
    const vitrineDiv = document.getElementById('vitrine');
    produtos.forEach(produto => {
        const produtoDiv = document.createElement('div');
        produtoDiv.className = 'produto';
        produtoDiv.innerHTML = `
            <h3>${produto.nome}</h3>
            <p>Preço: R$ ${produto.preco}</p>
            <button onclick='adicionarAoCarrinho(${JSON.stringify(produto)})'>Adicionar ao Carrinho</button>
        `;
        vitrineDiv.appendChild(produtoDiv);
    });
}

// Chamar a função correta com base na página
if (window.location.pathname.includes('carrinho.html')) {
    exibirCarrinho();
} else if (window.location.pathname.includes('vitrine.html')) {
    exibirVitrine();
}
